window.addEventListener('beforeunload', (event) => {
//    alert("before click");
//    event.preventDefault();
//    document.body.style.display = "none";
    document.querySelector("#btn-close-console").click();
//    event.preventDefault();
    //wait(1000);
//    alert("after click");
    //document.getElementById('HiddenButton').dispatchEvent(new Event("click"));
//    return (event.returnValue = 'Do you want to leave?');
});

//onbeforeunload = (event) => {document.querySelector("#btn-close-console").click();};

//window.onbeforeunload = confirmExit;
//    function confirmExit() {
//        document.querySelector("#btn-close-console").click();
//        return "You have attempted to leave this page. Are you sure?";
//    }
